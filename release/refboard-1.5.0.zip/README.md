# RefBoard

RefBoard is a Blender add-on for keeping image references in a dedicated node editor.

It is made for quick boards: drop in images, paste screenshots, arrange references, align them, match sizes when needed, export portable boards, and keep working inside Blender.

## Features

- Drag and drop images and PDFs into a RefBoard node tree.
- Paste images from the clipboard with Ctrl + V.
- Add one or several images or PDFs from the sidebar.
- Add images through Shift + A.
- Arrange selected images as a row, column, or automatic grid.
- Align selected images to the active image.
- Match selected image width or height to the active image.
- Rotate or mirror individual images from the node controls.
- Select nodes by clicking their image area.
- Draw images behind their nodes with Blender-style outlines.
- Pack pasted clipboard bitmap images into the `.blend` file.
- Export and import portable `.refbmd` RefBoard files.
- Import PDFs as one image node per page.

## Supported Formats

Images: PNG, JPG, JPEG, TGA, BMP, EXR, and WEBP.

Documents: PDF when a compatible renderer is available.

Boards: REFBMD.

## Install

Use the packaged zip:

```text
release/refboard-1.5.0.zip
```

## Feedback

If something breaks, please include your Blender version, operating system, and a short description of what happened.

## License

GPL-3.0-or-later.
